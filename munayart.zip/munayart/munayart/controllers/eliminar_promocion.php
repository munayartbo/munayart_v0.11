<?php
include 'db_connection.php';

if (isset($_GET['cod_promocion'])) {
    $cod_promocion = $_GET['cod_promocion'];

    // Primero eliminar las relaciones en la tabla Aplica
    $conn->query("DELETE FROM Aplica WHERE CodPromocion = '$cod_promocion'");

    // Luego eliminar la promoción de la tabla Promocion
    $sql = "DELETE FROM Promocion WHERE CodPromocion = '$cod_promocion'";
    
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Promoción eliminada con éxito.'); window.location.href = '../views/admin_comunidades.php';</script>";
    } else {
        echo "Error al eliminar la promoción: " . $conn->error;
    }
}

$conn->close();
?>
