<?php
include 'db_connection.php';

if (isset($_GET['cod_usuario'])) {
    $cod_usuario = $_GET['cod_usuario'];

    // Primero, eliminar los productos asociados al artesano
    $sql_delete_productos = "DELETE FROM Producto WHERE CodArtesano = '$cod_usuario'";
    if ($conn->query($sql_delete_productos) === TRUE) {
        echo "Productos eliminados correctamente.<br>";
    } else {
        echo "Error al eliminar productos: " . $conn->error . "<br>";
    }

    // Después, eliminar al artesano de la tabla Artesano
    $sql_artesano = "DELETE FROM Artesano WHERE CodArtesano = '$cod_usuario'";
    if ($conn->query($sql_artesano) === TRUE) {
        echo "Artesano eliminado correctamente.<br>";
    } else {
        echo "Error al eliminar Artesano: " . $conn->error . "<br>";
    }

    // Eliminar de las tablas Cliente y Delivery
    $sql_cliente = "DELETE FROM Cliente WHERE CodCliente = '$cod_usuario'";
    $sql_delivery = "DELETE FROM Delivery WHERE CodDelivery = '$cod_usuario'";

    if ($conn->query($sql_cliente) === TRUE) {
        echo "Cliente eliminado correctamente<br>";
    } else {
        echo "Error al eliminar Cliente: " . $conn->error . "<br>";
    }

    if ($conn->query($sql_delivery) === TRUE) {
        echo "Delivery eliminado correctamente<br>";
    } else {
        echo "Error al eliminar Delivery: " . $conn->error . "<br>";
    }

    // Finalmente, eliminar al usuario de la tabla Usuario
    $sql_usuario = "DELETE FROM Usuario WHERE CodUsuario = '$cod_usuario'";
    
    if ($conn->query($sql_usuario) === TRUE) {
        echo "<script>alert('Usuario eliminado con éxito.'); window.location.href = '../views/admin_comunidades.php';</script>";
    } else {
        echo "Error al eliminar Usuario: " . $conn->error . "<br>";
    }
} else {
    echo "No se recibió el código de usuario.";
}

$conn->close();
?>
