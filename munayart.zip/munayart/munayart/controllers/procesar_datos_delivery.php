<?php
session_start();
include 'db_connection.php';

// Verificar que el usuario tenga el rol de delivery
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'delivery') {
    echo "<script>
              alert('No tienes el rol de Delivery');
              window.location.href = '../views/loginIniReg.php';
          </script>";
    exit();
}

// Obtener los datos enviados desde el formulario
$tipo_vehiculo = $_POST['tipo_vehiculo'];
$placa = $_POST['placa'];
$cod_comunidad = $_POST['cod_comunidad']; // CodComunidad seleccionado en el formulario
$hora_ingreso = $_POST['hora_ingreso'];
$hora_salida = $_POST['hora_salida'];

// Obtener el ID del delivery desde la sesión
$cod_delivery = $_SESSION['user_id'];

// Obtener el nombre de la comunidad usando el CodComunidad
$sql_comunidad = "SELECT Nombre FROM comunidad WHERE CodComunidad = ?";
$stmt_comunidad = $conn->prepare($sql_comunidad);
$stmt_comunidad->bind_param("i", $cod_comunidad);
$stmt_comunidad->execute();
$result_comunidad = $stmt_comunidad->get_result();

// Verificar que se haya encontrado la comunidad
if ($result_comunidad->num_rows > 0) {
    $row_comunidad = $result_comunidad->fetch_assoc();
    $zona_cobertura = $row_comunidad['Nombre']; // Nombre de la comunidad
} else {
    echo "<script>alert('Comunidad no encontrada.'); window.location.href = '../views/completar_datos_delivery.php';</script>";
    exit();
}

// Inicializar la variable de la ruta de la imagen
$imagen_ruta = "";

// Verificar si el archivo fue enviado
// Inicializar la variable de la ruta de la imagen
$imagen_ruta = "";

// Verificar si el archivo fue enviado
if (isset($_FILES['foto_perfil']) && $_FILES['foto_perfil']['error'] == 0) {
    $foto_perfil = $_FILES['foto_perfil'];
    $target_dir = "../views/imagenes/"; // Carpeta donde se guardarán las imágenes de perfil
    $target_file = $target_dir . basename($foto_perfil["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Verificar si el archivo es una imagen real
    $check = getimagesize($foto_perfil["tmp_name"]);
    if ($check !== false) {
        $uploadOk = 1;
    } else {
        echo "<script>alert('El archivo no es una imagen.'); window.location.href = '../views/completar_datos_delivery.php';</script>";
        $uploadOk = 0;
    }

    // Verificar si ya existe la imagen
    if (file_exists($target_file)) {
        echo "<script>alert('La imagen ya existe.'); window.location.href = '../views/completar_datos_delivery.php';</script>";
        $uploadOk = 0;
    }

    // Limitar el tamaño de la imagen (ej. máximo 5MB)
    if ($foto_perfil["size"] > 5000000) {
        echo "<script>alert('El archivo es demasiado grande.'); window.location.href = '../views/completar_datos_delivery.php';</script>";
        $uploadOk = 0;
    }

    // Permitir solo ciertos formatos de imagen
    if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" && $imageFileType != "webp") {
        echo "<script>alert('Solo se permiten archivos JPG, JPEG, PNG y GIF.'); window.location.href = '../views/completar_datos_delivery.php';</script>";
        $uploadOk = 0;
    }

    // Verificar si $uploadOk es 0 debido a un error
    if ($uploadOk == 0) {
        echo "<script>alert('Tu archivo no se pudo subir.'); window.location.href = '../views/completar_datos_delivery.php';</script>";
    } else {
        // Si todo está bien, subir la imagen
        if (move_uploaded_file($foto_perfil["tmp_name"], $target_file)) {
            // Guardar solo el nombre de la imagen o la ruta relativa
            $imagen_ruta = "../views/imagenes/" . basename($foto_perfil["name"]);
        } else {
            echo "<script>alert('Hubo un error subiendo tu archivo.'); window.location.href = '../views/completar_datos_delivery.php';</script>";
        }
    }
}


// Comprobar si el delivery ya tiene un registro en la base de datos
$sql_check = "SELECT * FROM delivery WHERE CodDelivery = ?";
$stmt_check = $conn->prepare($sql_check);
$stmt_check->bind_param("i", $cod_delivery);
$stmt_check->execute();
$result_check = $stmt_check->get_result();

// Si ya existe un registro, actualizar los datos. Si no, insertar uno nuevo.
if ($result_check->num_rows > 0) {
    // Actualizar los datos existentes
    if (!empty($imagen_ruta)) {
        $sql_update = "UPDATE delivery SET TipoVehiculo = ?, Placa = ?, ZonaCobertura = ?, HoraIngreso = ?, HoraSalida = ?, Imagen = ? WHERE CodDelivery = ?";
        $stmt_update = $conn->prepare($sql_update);
        $stmt_update->bind_param("sssssii", $tipo_vehiculo, $placa, $zona_cobertura, $hora_ingreso, $hora_salida, $imagen_ruta, $cod_delivery);
    } else {
        $sql_update = "UPDATE delivery SET TipoVehiculo = ?, Placa = ?, ZonaCobertura = ?, HoraIngreso = ?, HoraSalida = ? WHERE CodDelivery = ?";
        $stmt_update = $conn->prepare($sql_update);
        $stmt_update->bind_param("sssssi", $tipo_vehiculo, $placa, $zona_cobertura, $hora_ingreso, $hora_salida, $cod_delivery);
    }

    if ($stmt_update->execute()) {
        echo "<script>alert('Datos del repartidor actualizados correctamente'); window.location.href = '../views/subir_producto.php';</script>";
    } else {
        echo "<script>alert('Error al actualizar los datos'); window.location.href = '../views/completar_datos_delivery.php';</script>";
    }

    $stmt_update->close();
} else {
    // Insertar nuevo registro
    $sql_insert = "INSERT INTO delivery (CodDelivery, TipoVehiculo, Placa, ZonaCobertura, HoraIngreso, HoraSalida, Imagen) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt_insert = $conn->prepare($sql_insert);
    $stmt_insert->bind_param("issssss", $cod_delivery, $tipo_vehiculo, $placa, $zona_cobertura, $hora_ingreso, $hora_salida, $imagen_ruta);

    if ($stmt_insert->execute()) {
        echo "<script>alert('Datos del repartidor guardados correctamente'); window.location.href = '../views/subir_producto.php';</script>";
    } else {
        echo "<script>alert('Error al guardar los datos'); window.location.href = '../views/completar_datos_delivery.php';</script>";
    }

    $stmt_insert->close();
}

$stmt_check->close();
$conn->close();
?>