<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FILTRADO</title>
    <!-- =================================
           FILTRADO DE PRODUCTOS
        ================================== -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/2.9.2/umd/popper.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="estiloPro.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <style>
        #hm-menu {
            display: none;
            position: fixed;
            /* Cambiado a fixed para que se mantenga fijo en la pantalla */
            height: 40px;
            width: auto;
            top: 5px;
            right: 10px;
            /* Ajustar a la derecha */
            background-color: #fff;
            border-radius: 5px;
            padding: 0;
            white-space: nowrap;
            display: flex;
            align-items: center;
            z-index: 1000;
            /* Asegurarse de que esté por encima de otros elementos */
        }
    </style>
</head>

<body>
    <?php
    // Conexión a la base de datos
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "munayart";
    $port = "3307";

    $conn = new mysqli($servername, $username, $password, $dbname, $port);

    if ($conn->connect_error) {
        die("Conexión fallida: " . $conn->connect_error);
    }

    // Consultar los tipos únicos de producto desde la base de datos
    $tipoQuery = "SELECT DISTINCT tipo FROM producto";
    $tipoResult = $conn->query($tipoQuery);

    // Consultar los materiales únicos de producto desde la base de datos
    $tipoQuery = "SELECT DISTINCT Material FROM producto";
    $tipoResultMaterial = $conn->query($tipoQuery);
    ?>

    <div class="col-12 grid-margin">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Buscador</h4>
                <form id="form2" name="form2">
                    <div class="row">
                        <div class="mb-3">
                            <label class="form-label">Nombre del producto</label>
                            <input type="text" class="form-control" id="buscar" name="buscar">
                        </div>
                    </div>
                    <!-- Filtros -->
                    <h4 class="card-title">Filtro de búsqueda</h4>
                    <div class="row">
                        <div class="col-6">
                            <label class="form-label">Tipo</label>
                            <select id="buscarTipo" name="buscarTipo" class="form-control mt-2">
                                <option value="">Todos</option>
                                <!-- Rellenar el select con los tipos obtenidos de la base de datos -->
                                <?php while ($rowTipo = $tipoResult->fetch_assoc()) { ?>
                                    <option value="<?php echo $rowTipo['tipo']; ?>">
                                        <?php echo $rowTipo['tipo']; ?>
                                    </option>
                                <?php } ?>
                            </select>
                        </div>
                        <div class="col-6">
                            <label class="form-label">Material</label>
                            <select id="material" name="material" class="form-control mt-2">
                                <option value="">Todos</option>
                                <?php while ($rowMate = $tipoResultMaterial->fetch_assoc()) { ?>
                                    <option value="<?php echo $rowMate['Material']; ?>">
                                        <?php echo $rowMate['Material']; ?>
                                    </option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>

                    <div class="row mt-3">
                        <div class="col-6">
                            <label class="form-label">Precio desde</label>
                            <input type="number" id="buscapreciodesde" name="buscapreciodesde"
                                class="form-control mt-2">
                        </div>
                        <div class="col-6">
                            <label class="form-label">Precio hasta</label>
                            <input type="number" id="buscapreciohasta" name="buscapreciohasta"
                                class="form-control mt-2">
                        </div>
                    </div>

                    <h4 class="card-title mt-4">Ordenar por</h4>
                    <div class="row">
                        <div class="col-12">
                            <select id="orden" name="orden" class="form-control mt-2">
                                <option value="">Selecciona el orden</option>
                                <option value="1">Ordenar por nombre</option>
                                <option value="2">Ordenar por tipo</option>
                                <option value="3">Ordenar por material</option>
                                <option value="4">Ordenar por precio de menor a mayor</option>
                                <option value="5">Ordenar por precio de mayor a menor</option>
                            </select>
                        </div>
                    </div>
                </form>

                <p id="result-count" style="font-weight: bold;">0 Resultados encontrados</p>

                <div id="product-results" class="product-grid-container"></div>
            </div>
        </div>
    </div>

    <script>
        // Función para realizar la búsqueda automáticamente al cambiar los filtros
        function realizarBusqueda() {
            // Crear el objeto de formulario
            var formData = new FormData(document.getElementById('form2'));

            // Realizar la solicitud AJAX
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "procesar_busqueda.php", true);
            xhr.onload = function () {
                if (xhr.status === 200) {
                    // Insertar los productos y actualizar el número de resultados
                    var response = JSON.parse(xhr.responseText);
                    document.getElementById('product-results').innerHTML = response.html;
                    document.getElementById('result-count').textContent = response.count + " Resultados encontrados";
                }
            };
            xhr.send(formData);
        }

        // Escuchar los cambios en los campos del formulario
        document.querySelectorAll('#form2 input, #form2 select').forEach(function (element) {
            element.addEventListener('input', realizarBusqueda);
        });

        // Cargar todos los productos al inicio de la página
        window.onload = function () {
            realizarBusqueda();  // Cargar los productos al inicio
            ajustarAltura();     // Ajustar la altura inicial del iframe
        };

        // Función para ajustar la altura del iframe
        function ajustarAltura() {
            var height = document.body.scrollHeight;
            window.parent.postMessage(height, '*');
        }

        // Llamar a ajustarAltura() después de cada actualización de los productos
        function realizarBusqueda() {
            var formData = new FormData(document.getElementById('form2'));
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "procesar_busqueda.php", true);
            xhr.onload = function () {
                if (xhr.status === 200) {
                    var response = JSON.parse(xhr.responseText);
                    document.getElementById('product-results').innerHTML = response.html;
                    document.getElementById('result-count').textContent = response.count + " Resultados encontrados";

                    ajustarAltura();  // Ajustar la altura después de cargar los nuevos productos
                }
            };
            xhr.send(formData);
        }
    </script>

</body>

</html>