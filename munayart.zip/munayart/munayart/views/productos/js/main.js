let productos = [];

// Cargar todos los productos al inicio
fetch("./productos.php")
    .then(response => response.json())
    .then(data => {
        productos = data;
        console.log("Productos cargados:", productos); // Verifica que los productos se estén cargando correctamente
        cargarProductos(productos); // Cargar todos los productos al inicio

        // Crear y disparar un evento personalizado para indicar que los productos están cargados
        const event = new Event('productosCargados');
        window.dispatchEvent(event);
    })
    .catch(error => console.error("Error al cargar los productos:", error));



const contenedorProductos = document.querySelector("#contenedor-productos");
const botonesCategorias = document.querySelectorAll(".boton-categoria");
const tituloPrincipal = document.querySelector("#titulo-principal");
let botonesAgregar = document.querySelectorAll(".producto-agregar");
const numerito = document.querySelector("#numerito");

// Función para cargar productos en el contenedor
function cargarProductos(productosElegidos) {
    console.log("Productos recibidos:", productosElegidos); // Para depuración
    contenedorProductos.innerHTML = "";

    productosElegidos.forEach(producto => {
        const div = document.createElement("div");
        div.classList.add("producto");
        div.innerHTML = `
            <img class="producto-imagen" src="${producto.imagen}" alt="${producto.titulo}">
            <div class="producto-detalles">
                <h3 class="producto-titulo">${producto.titulo}</h3>
                <p class="producto-precio">Bs. ${producto.precio}</p>
                
                <!-- Mostrar stock disponible -->
                <p class="producto-stock">Stock: ${producto.stock}</p>
                
                <!-- Apartado para la cantidad -->
                <label for="cantidad-${producto.id}">Cantidad:</label>
                <input type="number" id="cantidad-${producto.id}" min="1" value="1" class="producto-cantidad" 
                    max="${producto.stock}" ${producto.stock === 0 ? 'disabled' : ''}>
                
                <a style="text-decoration: none;" target="_top" href="../Producto_individual/detalles_producto.php?CodProducto=${producto.id}">
                    <button class="producto-detalles-boton">Ver Detalles</button>
                </a>
                
                <!-- Deshabilitar el botón si no hay stock -->
                <button class="producto-agregar" id="${producto.id}" ${producto.stock === 0 ? 'disabled' : ''}>
                    ${producto.stock > 0 ? 'Agregar' : 'Agotado'}
                </button>
            </div>
        `;
        contenedorProductos.append(div);
    });
    actualizarBotonesAgregar();
}



// Escuchar clics en botones de categoría
botonesCategorias.forEach(boton => {
    boton.addEventListener("click", (e) => {
        // Remover la clase 'active' de todos los botones y añadirla al botón actual
        botonesCategorias.forEach(boton => boton.classList.remove("active"));
        e.currentTarget.classList.add("active");

        if (e.currentTarget.id === "todos") {
            // Si se selecciona "Todos los productos", cargar todos los productos
            cargarProductos(productos);
            tituloPrincipal.innerText = "Todos los productos"; // Restablecer título
        } else {
            // Filtrar productos basados en el id del botón, que coincide con el tipo de producto
            const productosFiltrados = productos.filter(producto => producto.tipo.toLowerCase() === e.currentTarget.id.toLowerCase());

            // Actualizar el título principal y cargar los productos filtrados
            tituloPrincipal.innerText = e.currentTarget.innerText; // Usar el texto del botón como título
            cargarProductos(productosFiltrados);
        }
    });
});

// Función para actualizar botones de agregar al carrito
function actualizarBotonesAgregar() {
    botonesAgregar = document.querySelectorAll(".producto-agregar");

    botonesAgregar.forEach(boton => {
        boton.addEventListener("click", agregarAlCarrito);
    });
}

let productosEnCarrito;

let productosEnCarritoLS = localStorage.getItem("productos-en-carrito");

if (productosEnCarritoLS) {
    productosEnCarrito = JSON.parse(productosEnCarritoLS);
    actualizarNumerito();
} else {
    productosEnCarrito = [];
}

function agregarAlCarrito(e) {
    Toastify({
        text: "Producto agregado",
        duration: 3000,
        close: true,
        gravity: "top", // `top` or `bottom`
        position: "right", // `left`, `center` or `right`
        stopOnFocus: true, // Prevents dismissing of toast on hover
        style: {
            background: "linear-gradient(to right, #1d3354, #467599)",
            borderRadius: "2rem",
            textTransform: "uppercase",
            fontSize: ".75rem"
        },
        offset: {
            x: '1.5rem', // horizontal axis - can be a number or a string indicating unity. eg: '2em'
            y: '1.5rem' // vertical axis - can be a number or a string indicating unity. eg: '2em'
        },
        onClick: function () { } // Callback after click
    }).showToast();

    const idBoton = e.currentTarget.id;
    const productoAgregado = productos.find(producto => producto.id === idBoton);

    if (productosEnCarrito.some(producto => producto.id === idBoton)) {
        const index = productosEnCarrito.findIndex(producto => producto.id === idBoton);
        productosEnCarrito[index].cantidad++;
    } else {
        productoAgregado.cantidad = 1;
        productosEnCarrito.push(productoAgregado);
    }

    actualizarNumerito();

    localStorage.setItem("productos-en-carrito", JSON.stringify(productosEnCarrito));
}

function actualizarNumerito() {
    let nuevoNumerito = productosEnCarrito.reduce((acc, producto) => acc + producto.cantidad, 0);
    numerito.innerText = nuevoNumerito;
}
