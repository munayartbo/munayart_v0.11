<?php
include '../../controllers/db_connection.php';
session_start();
function obtenerTiempoEstimado($departamento) {
    switch ($departamento) {
        case 'La Paz':
            return '50 minutos';
        case 'Potosí':
            return '40 minutos';
        case 'Cochabamba':
            return '50 minutos';
        case 'Oruro':
            return '30 minutos';
        case 'Beni':
            return '45 minutos';
        case 'Santa Cruz':
            return '40 minutos';
        case 'Pando':
            return '20 minutos';
        case 'Tarija':
            return '30 minutos';
        case 'Chuquisaca':
            return '35 minutos';
        default:
            return 'Tiempo estimado no disponible';
    }
}

if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'cliente') {
    echo "<script>
              alert('No tienes el rol de Cliente');
              window.location.href = '../../views/loginIniReg.php';
          </script>";
    exit();
}

// Obtener el ID del cliente de la sesión
$CodCliente = $_SESSION['user_id'];

// Consulta para obtener los pedidos del cliente
$sql = "
    SELECT 
        p.CodPedido,
        p.Fecha AS FechaPedido,
        p.Estado AS EstadoPedido,
        u.Departamento,
        u.Provincia,
        u.Calle,
        u.Zona,
        u.NroPuerta,
        pg.Tipo AS TipoPago,
        pg.Total AS MontoTotal,
        s.User
    FROM 
        Pedido p
    JOIN Pago pg ON p.CodPago = pg.CodPago
    JOIN Ubicacion u ON p.CodUbicacion = u.CodUbicacion
    JOIN Carrito c ON pg.CodCarrito = c.CodCarrito
    LEFT JOIN Entrega e ON e.CodPedido = p.CodPedido
    LEFT JOIN Delivery d ON e.CodDelivery = d.CodDelivery
    LEFT JOIN Usuario s ON d.CodDelivery = s.CodUsuario
    WHERE c.CodCliente = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $CodCliente);
$stmt->execute();
$result = $stmt->get_result();

// Comprobar si hay resultados
if ($result->num_rows === 0) {
    echo "<script>alert('No tienes pedidos registrados.');</script>";
} else {
    $result->data_seek(0); // Resetear el puntero para volver a utilizar los datos
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis Pedidos - MunayArt</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #f0f0f0;
            color: #333;
        }

        .container {
            background-color: #FFFFFF;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            padding: 40px;
            max-width: 900px;
            width: 100%;
            text-align: center;
            position: relative;
        }

        h2 {
            color: #D64045;
            text-align: left;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ccc;
        }

        th {
            background-color: #D64045;
            color: white;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        button {
            background-color: #D64045;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            font-size: 1em;
            cursor: pointer;
        }

        button:hover {
            background-color: #b52e37;
        }

        .no-pedidos {
            margin-top: 20px;
            color: #D64045;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Mis Pedidos</h2>
        <?php if ($result->num_rows === 0): ?>
            <p class="no-pedidos">No tienes pedidos registrados.</p>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>Código de Pedido</th> <!-- Nueva columna para el Código de Pedido -->
                        <th>Fecha</th>
                        <th>Ubicación</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                        <th>Delivery</th> 
                        <th>Tiempo Estimado</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($pedido = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $pedido['CodPedido']; ?></td> <!-- Mostrar el Código de Pedido -->
                            <td><?php echo $pedido['FechaPedido']; ?></td>
                            <td><?php echo "{$pedido['Departamento']}, {$pedido['Provincia']}, {$pedido['Calle']}, {$pedido['Zona']}, Nro: {$pedido['NroPuerta']}"; ?></td>
                            <td><?php echo $pedido['EstadoPedido']; ?></td>
                            <td>
                                <?php if ($pedido['EstadoPedido'] == 'Pendiente' || $pedido['EstadoPedido'] == 'Asignado' || $pedido['EstadoPedido'] == 'En Camino'): ?>
                                    <button onclick="actualizarEstado(<?php echo $pedido['CodPedido']; ?>, 'Cancelado')">Cancelar</button>
                                <?php elseif ($pedido['EstadoPedido'] == 'Entregado'): ?>
                                    <button onclick="mostrarFormularioDevolucion(<?php echo $pedido['CodPedido']; ?>)">Devolver</button>
                                <?php else: ?>
                                    <span>No disponible</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo $pedido['User'] ?: 'No asignado'; ?></td>
                            <td>
                                <?php
                                // Obtener el tiempo estimado basado en el departamento
                                $departamento = $pedido['Departamento'];
                                echo obtenerTiempoEstimado($departamento);
                                ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    <!-- Formulario modal de devolución -->
<div id="formularioDevolucion" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0, 0, 0, 0.5); justify-content: center; align-items: center;">
    <div style="background-color: white; padding: 20px; border-radius: 10px; width: 400px;">
        <h3>Motivo de Devolución</h3>
        <form id="devolucionForm" action="../../controllers/devolver_pedido.php" onsubmit="enviarDevolucion(event)">
            <input type="hidden" id="CodPedido" name="CodPedido">
            <textarea name="Motivo" required placeholder="Escribe el motivo de tu devolución..." style="width: 100%; height: 100px;"></textarea>
            <div style="margin-top: 10px;">
                <button type="submit" style="background-color: #D64045; color: white; border: none; padding: 10px; border-radius: 5px;">Enviar</button>
                <button type="button" onclick="cerrarFormularioDevolucion()" style="margin-left: 10px; background-color: grey; color: white; border: none; padding: 10px; border-radius: 5px;">Cancelar</button>
            </div>
        </form>
    </div>
</div>

<script>
    function actualizarEstado(codPedido, accion) {
        const mensaje = (accion === 'Cancelado') 
            ? '¿Estás seguro de que deseas cancelar este pedido?' 
            : '¿Estás seguro de que deseas devolver este pedido?';

        if (confirm(mensaje)) {
            if (accion === 'Cancelado') {
                window.location.href = '../../controllers/actualizar_pedido.php?CodPedido=' + codPedido + '&accion=' + accion;
            } else if (accion === 'Devolver') {
                mostrarFormularioDevolucion(codPedido);
            }
        } 
    }

    function mostrarFormularioDevolucion(codPedido) {
        document.getElementById('CodPedido').value = codPedido;
        document.getElementById('formularioDevolucion').style.display = 'flex';
    }

    function cerrarFormularioDevolucion() {
        document.getElementById('formularioDevolucion').style.display = 'none';
    }

    async function enviarDevolucion(event) {
        event.preventDefault(); // Evita el envío normal del formulario
        const formData = new FormData(event.target);
        const response = await fetch(event.target.action, {
            method: 'POST',
            body: formData
        });

        if (response.ok) {
            const codPedido = document.getElementById('CodPedido').value;
            window.location.href = '../../controllers/actualizar_pedido.php?CodPedido=' + codPedido + '&accion=Devolver';
        } else {
            alert('Error al procesar la devolución. Intente nuevamente.');
        }
    }
</script>

</body>
</html>