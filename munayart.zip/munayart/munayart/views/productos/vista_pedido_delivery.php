<?php
include '../../controllers/db_connection.php';
session_start();

// Verificar que el usuario tenga el rol de delivery
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'delivery') {
    echo "<script>
              alert('No tienes el rol de Delivery');
              window.location.href = '../../views/loginIniReg.php';
          </script>";
    exit();
}

// Obtener el ID del delivery de la sesión
$CodDelivery = $_SESSION['user_id'];

// Consulta para obtener los pedidos asignados al delivery
$sql = "
    SELECT 
    p.CodPedido,
    p.Fecha AS FechaPedido,
    p.Estado AS EstadoPedido,
    u.Departamento,
    u.Provincia,
    u.Calle,
    u.Zona,
    u.NroPuerta,
    pg.Total AS MontoTotal,
    usr.Nombre AS NombreCliente
FROM 
    entrega e
JOIN 
    pedido p ON e.CodPedido = p.CodPedido
JOIN 
    Pago pg ON p.CodPago = pg.CodPago
JOIN 
    Ubicacion u ON p.CodUbicacion = u.CodUbicacion
JOIN 
    Carrito c ON pg.CodCarrito = c.CodCarrito
JOIN 
    Cliente cl ON c.CodCliente = cl.CodCliente
JOIN 
    Usuario usr ON cl.CodCliente = usr.CodUsuario
WHERE 
    e.CodDelivery = ? 
    AND p.Estado IN ('Asignado', 'En Camino');";

$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $CodDelivery);
$stmt->execute();
$result = $stmt->get_result();

// Comprobar si hay resultados
if ($result->num_rows === 0) {
    echo "<script>alert('No hay pedidos para mostrar.');</script>";
} else {
    $result->data_seek(0); // Resetear el puntero para volver a utilizar los datos
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pedidos - MunayArt</title>
    <style>
        /* Estilos similares a los proporcionados anteriormente */
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #f0f0f0;
            color: #333;
        }

        .container {
            background-color: #FFFFFF;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            padding: 40px;
            max-width: 900px;
            width: 100%;
            text-align: center;
            position: relative;
        }

        h2 {
            color: #D64045;
            text-align: left;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ccc;
        }

        th {
            background-color: #D64045;
            color: white;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        button {
            background-color: #D64045;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            font-size: 1em;
            cursor: pointer;
        }

        button:hover {
            background-color: #b52e37;
        }

        .no-pedidos {
            margin-top: 20px;
            color: #D64045;
        }

        .btn-container {
            text-align: left;
            margin-bottom: 20px;
        }

    </style>
</head>
<body>
    <div class="container">
        <div class="btn-container">
            <button onclick="window.location.href = '../../views/completar_datos_delivery.php';">Completar Datos Delivery</button>
        </div>

        <h2>Pedidos Asignados y En Camino a Entregados</h2>
        <?php if ($result->num_rows === 0): ?>
            <p class="no-pedidos">No hay pedidos para mostrar.</p>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>Pedido</th>
                        <th>Nombre Cliente</th>
                        <th>Fecha</th>
                        <th>Ubicación</th>
                        <th>Monto Total</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($pedido = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $pedido['CodPedido']; ?></td>
                            <td><?php echo $pedido['NombreCliente']; ?></td>
                            <td><?php echo $pedido['FechaPedido']; ?></td>
                            <td><?php echo "{$pedido['Departamento']}, {$pedido['Provincia']}, {$pedido['Calle']}, {$pedido['Zona']}, Nro: {$pedido['NroPuerta']}"; ?></td>
                            <td><?php echo $pedido['MontoTotal']; ?></td>
                            <td><?php echo $pedido['EstadoPedido']; ?></td>
                            <td>
                            <?php 
                            if ($pedido['EstadoPedido'] == 'Asignado'): ?>
                                <button onclick="actualizarEstado(<?php echo $pedido['CodPedido']; ?>, 'EnCamino')">En Camino</button>
                            <?php elseif ($pedido['EstadoPedido'] == 'En Camino'): ?>
                                <button onclick="actualizarEstado(<?php echo $pedido['CodPedido']; ?>, 'Entregar')">Entregado</button>
                            <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <script>
        function actualizarEstado(codPedido, accion) {
            let mensaje;
            if (accion === 'EnCamino') {
                mensaje = '¿Marcar este pedido como En Camino?';
            } else if (accion === 'Entregar') {
                mensaje = '¿Marcar este pedido como Entregado?';
            } else {
                mensaje = '¿Estás seguro de que deseas realizar esta acción?';
            }

            if (confirm(mensaje)) {
                window.location.href = `../../controllers/actualizar_pedido_delivery.php?CodPedido=${codPedido}&accion=${accion}`;
            }
        }
    </script>
</body>
</html>
